# PROC36-1_4-referencia-maestra1
## Actividad de la maestra 1 para la clase 36 nivel PRO 1-4.
## Nombre en inglés: synchronousBallMovement

Movimiento de la pelota sincronizado.
